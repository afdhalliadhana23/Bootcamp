/// <reference types="cypress"/>
 
describe('Login Feature',() => {
    it('Pengguna login dengan username dan pasword yang sudah di hapus',() => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.get('[class="oxd-text oxd-text--h5 orangehrm-login-title"]').should('have.text','Login'); 
        cy.get('[name="username"]').type('toretto');
        cy.get('[name="password"]').type('qwerty123456');
        cy.request({
            method : "get",
            url:'https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages',
            failonstatuscode: false

            
        }).then((response)=>{
            console.log('login Required. response code:',response.status);
            expect(response.status).to.not.equal(304);
        });

        //cy.intercept("Get","https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages").as("loginRequest");
        //cy.intercept("Get","**/employees/action-summary").as("actionsummary");
        cy.get('[class="oxd-button oxd-button--medium oxd-button--main orangehrm-login-button"]').click();
        cy.get('[class="oxd-text oxd-text--p oxd-alert-content-text"]').should('have.text','Invalid credentials');
        //cy.wait("@actionsummary").then((intercept) => {
          //  console.log('status code:', intercept.response.statusCode);
            //expect(intercept.response.statusCode).to.not.equal(304);
        /*cy.wait("@actionsummary").then((intercept) => {
            expect(intercept.response.statusCode).to.equal(5000);*/
        //});
    })
    
 
})