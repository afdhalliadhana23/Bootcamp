/// <reference types="cypress"/>
 
describe('Login Feature',() => {
    it('Pengguna Login dengan username dan password yang sama',() => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.get('[class="oxd-text oxd-text--h5 orangehrm-login-title"]').should('have.text','Login'); 
        cy.get('[name="username"]').type('admin123');
        cy.get('[name="password"]').type('Admin');
        cy.intercept("Get","https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages").as("actionsummary");
        //cy.intercept("Get","**/employees/action-summary").as("actionsummary");
        cy.get('[class="oxd-button oxd-button--medium oxd-button--main orangehrm-login-button"]').click();
        cy.get('[class="oxd-text oxd-text--p oxd-alert-content-text"]').should('have.text','Invalid credentials');
        cy.wait("@actionsummary").then((intercept) => {
            console.log('status code:', intercept.response.statusCode);
            expect(intercept.response.statusCode).to.equal(304);
        });

        /*cy.wait("@actionsummary").then((intercept) => {
            expect(intercept.response.statusCode).to.equal(404);
        });*/
    
    })
    
 
})