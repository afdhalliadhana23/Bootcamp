/// <reference types="cypress"/>
 
describe('Login Feature',() => {
    it('Pengguna Login dengan username kosong dan password',() => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.get('[class="oxd-text oxd-text--h5 orangehrm-login-title"]').should('have.text','Login'); 
        cy.get('[name="username"]').type(' ');
        cy.get('[name="password"]').type('admin123');
        cy.request({
            method : "get",
            url:'https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages',
            failonstatuscode: false

            
        }).then((response)=>{
            console.log('login Required. response code:',response.status);
            expect(response.status).to.not.equal(304);
        });

        //cy.intercept("Get","https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages").as("loginRequest");
        //cy.intercept("Get","**/employees/action-summary").as("actionsummary");
        cy.get('[class="oxd-button oxd-button--medium oxd-button--main orangehrm-login-button"]').click();
        //cy.get('[class="oxd-text oxd-text--p oxd-alert-content-text"]').should('have.text','Invalid credentials');
  
//       cy.wait('@loginRequest').then((intercept) => {
        //if(interception.response.statusCode === 304)
        //console.log('status code:', intercept.response.statusCode);
        //expect(intercept.response.statusCode).to.not.equal(304);

        cy.get('[class="oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message"]').should('have.text','Required');
        
        /*cy.wait("@actionsummary").then((intercept) => {
            expect(intercept.response.statusCode).to.equal(404);*/

        //});
    })
    
})