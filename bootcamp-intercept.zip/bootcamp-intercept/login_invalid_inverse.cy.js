/// <reference types="cypress"/>
 
describe('Login Feature',() => {
    it('Pengguna Login dengan username dan password terbalik',() => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.get('[class="oxd-text oxd-text--h5 orangehrm-login-title"]').should('have.text','Login'); 
        cy.get('[name="username"]').type('admin');
        cy.get('[name="password"]').type('admin123');
        cy.intercept("Get","**/employees/action-summary").as("actionsummary");
        cy.get('[class="oxd-button oxd-button--medium oxd-button--main orangehrm-login-button"]').click();
        cy.get('[class="oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module"]').should('have.text','Dashboard')
        cy.wait("@actionsummary").then((intercept) => {
            expect(intercept.response.statusCode).to.equal(200);
        });
    })
    
 
})